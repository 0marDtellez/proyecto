package com.example.prollectofinal.scrins

import android.annotation.SuppressLint
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.prollectofinal.models.Accio
import com.example.prollectofinal.navegar.Nave
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun AddScreenAccion(
    navController: NavController,
){
    Scaffold(
        topBar = {
            TopAppBar(){
                Icon(
                    imageVector =Icons.Default.ArrowBack,
                    contentDescription ="Arrow Back",
                    modifier = Modifier
                        .clickable {
                            navController.popBackStack()
                        }
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "peliculas")
            }},
        floatingActionButton ={
            FloatingActionButton(
                modifier = Modifier.size(32.dp),
                onClick = { navController.navigate(route =Nave.AppAccio.route)}
            ) {
                Icon(
                    imageVector = Icons.Default.AddCircle,
                    contentDescription ="Agregar",
                    tint = Color.White
                )
            }
        },
        floatingActionButtonPosition = FabPosition.End
    ){
        BodyContentAccio(navController)
    }
}
@Composable
fun BodyContentAccio(
    navController:NavController
){
    var accionNombre by remember {mutableStateOf("")}
    var accionFecha by remember {mutableStateOf("")}
    var accionReseña by remember {mutableStateOf("")}
    Box(modifier = Modifier.fillMaxWidth()){
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(all = 16.dp)
        ) {
            TextField(
                modifier =Modifier.fillMaxWidth(),
                value=accionNombre,
                onValueChange={accionNombre= it},
                label ={Text("Nombre de la pelicula: ")}
            )
            Spacer(modifier = Modifier.height(20.dp))
            TextField(
                modifier =Modifier.fillMaxWidth(),
                value=accionFecha,
                onValueChange={accionFecha= it},
                label ={Text("fecha de lansamiento: ")}
            )
            Spacer(modifier = Modifier.height(20.dp))
            TextField(
                modifier =Modifier.fillMaxWidth(),
                value=accionReseña,
                onValueChange={accionReseña= it},
                label ={Text("Reseña: ")}
            )
            Spacer(modifier = Modifier.height(20.dp))
            Button(
                onClick = {
                    val accio = Accio(accionNombre,accionFecha.toInt(),accionReseña)
                    Firebase.firestore.collection("accion").add(accio)
                    navController.navigate(route =Nave.AppAccio.route)
                },
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .padding(vertical = 2.dp)
                    .fillMaxWidth()
            ) {
                Text(text = "añade una pelicula")
            }
        }
    }
}














