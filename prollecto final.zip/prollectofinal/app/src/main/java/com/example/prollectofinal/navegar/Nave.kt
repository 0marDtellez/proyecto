package com.example.prollectofinal.navegar

sealed class Nave(
    val route:String
){
    object Vistas:Nave(route = "Vistas")
    object Login:Nave(route = "Login")
    object Categorias:Nave(route = "Categorias")
    object AppAccio:Nave(route = "AppAccio")
    object AddScreenAccion:Nave(route = "AddScreenAccion")
    object AppTerror:Nave(route = "AppTerror")
    object AddScreenTerror:Nave(route = "AddScreenTerror")
    object AppFamilia:Nave(route = "AppFamilia")
    object AddScreenFamilia:Nave(route = "AddScreenFamilia")
    object AppComedia:Nave(route = "AppComedia")
    object AddScreenComedia:Nave(route = "AddScreenComedia")
}
