package com.example.prollectofinal.scrins

import android.annotation.SuppressLint
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.prollectofinal.R
import com.example.prollectofinal.models.Familia
import com.example.prollectofinal.models.FamiliaViewModel
import com.example.prollectofinal.navegar.Nave

@Composable
fun FamiliaCard(
    familia: Familia
){
    Card(
        modifier = Modifier
            .padding(all = 16.dp)
            .fillMaxWidth()
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Text(text = "Nombre: ${familia.nombre} ", color = Color.Gray, fontSize = 16.sp)
            Text(text = "Fecha:${familia.fecha}", color = Color.Gray)
            Text(text = "Reseña: ${familia.descripcion} ", color = Color.Gray, fontSize = 12.sp)
        }
    }
}
@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun AppFamilia(
    navController: NavController,
    viewModel: FamiliaViewModel
){
    val logo= painterResource(R.drawable.raikuasa)
    Scaffold(
        topBar = {
            TopAppBar(){
                Icon(
                    imageVector =Icons.Default.ArrowBack,
                    contentDescription ="Arrow Back",
                    modifier = Modifier
                        .clickable {
                            navController.popBackStack()
                        }
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "peliculas")
            }},
        floatingActionButton ={
            FloatingActionButton(
                modifier = Modifier.size(32.dp),
                onClick = {navController.navigate(route = Nave.AddScreenFamilia.route)}
            ) {
                Icon(
                    imageVector = Icons.Default.AddCircle,
                    contentDescription ="Agregar",
                    tint = Color.White
                )
            }
        },
        floatingActionButtonPosition = FabPosition.End
    ){
        Box(modifier = Modifier.fillMaxSize()) {
            Image(
                painter =logo,
                contentDescription ="familis",
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(all = 4.dp)
            )
            Column() {
                LazyColumn(){
                    items(viewModel.famili.value){famili ->
                        FamiliaCard(famili)
                    }
                }
            }
        }
    }
}
