package com.example.prollectofinal.scrins

import android.annotation.SuppressLint
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.prollectofinal.models.Accio
import com.example.prollectofinal.models.Comedia
import com.example.prollectofinal.navegar.Nave
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun AddScreenComedia(
    navController: NavController,
){
    Scaffold(
        topBar = {
            TopAppBar(){
                Icon(
                    imageVector =Icons.Default.ArrowBack,
                    contentDescription ="Arrow Back",
                    modifier = Modifier
                        .clickable {
                            navController.popBackStack()
                        }
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "peliculas")
            }},
        floatingActionButton ={
            FloatingActionButton(
                modifier = Modifier.size(32.dp),
                onClick = { navController.navigate(route = Nave.AppComedia.route)}
            ) {
                Icon(
                    imageVector = Icons.Default.AddCircle,
                    contentDescription ="Agregar",
                    tint = Color.White
                )
            }
        },
        floatingActionButtonPosition = FabPosition.End
    ){
        BodyContentComedia(navController)
    }
}
@Composable
fun BodyContentComedia(
    navController:NavController
){
    var comediaNombre by remember { mutableStateOf("") }
    var comediaFecha by remember { mutableStateOf("") }
    var comediaReseña by remember { mutableStateOf("") }
    Box(modifier = Modifier.fillMaxWidth()){
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(all = 16.dp)
        ) {
            TextField(
                modifier = Modifier.fillMaxWidth(),
                value=comediaNombre,
                onValueChange={comediaNombre= it},
                label ={ Text("Nombre: ") }
            )
            Spacer(modifier = Modifier.height(20.dp))
            TextField(
                modifier = Modifier.fillMaxWidth(),
                value=comediaFecha,
                onValueChange={comediaFecha= it},
                label ={ Text("Fecha de estreno: ") }
            )
            Spacer(modifier = Modifier.height(20.dp))
            TextField(
                modifier = Modifier.fillMaxWidth(),
                value=comediaReseña,
                onValueChange={comediaReseña= it},
                label ={ Text("Critica: ") }
            )
            Spacer(modifier = Modifier.height(20.dp))
            Button(
                onClick = {
                    val come = Comedia(comediaNombre,comediaFecha.toInt(),comediaReseña)
                    Firebase.firestore.collection("comedia").add(come)
                    navController.navigate(route =Nave.AppComedia.route)
                },
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .padding(vertical = 8.dp)
                    .fillMaxWidth()
            ) {
                Text(text = "Crear comentario")
            }
        }
    }
}
