package com.example.prollectofinal.models

data class Familia(
    val nombre: String = "",
    val fecha: Int = 0,
    val descripcion:String=""
)
