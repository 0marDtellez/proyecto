package com.example.prollectofinal.models

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.firestore.ktx.toObjects
import com.google.firebase.ktx.Firebase

class AccionViewModel:ViewModel() {
    private  val _accio = mutableStateOf<List<Accio>>(emptyList())
    val accio: State<List<Accio>>
        get() = _accio
    private val query = Firebase.firestore.collection("accion")
    init {
        query.addSnapshotListener { value, _ ->
            if (value !=null){
                _accio.value = value.toObjects()
            }
        }
    }
}