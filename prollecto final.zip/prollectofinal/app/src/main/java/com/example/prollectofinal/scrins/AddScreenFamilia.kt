package com.example.prollectofinal.scrins.loguin

import android.annotation.SuppressLint
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.prollectofinal.models.Accio
import com.example.prollectofinal.models.Familia
import com.example.prollectofinal.navegar.Nave
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun AddScreenFamilia(
    navController: NavController,
){
    Scaffold(
        topBar = {
            TopAppBar(){
                Icon(
                    imageVector =Icons.Default.ArrowBack,
                    contentDescription ="Arrow Back",
                    modifier = Modifier
                        .clickable {
                            navController.popBackStack()
                        }
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "peliculas")
            }},
        floatingActionButton ={
            FloatingActionButton(
                modifier = Modifier.size(32.dp),
                onClick = { navController.navigate(route = Nave.AppFamilia.route)}
            ) {
                Icon(
                    imageVector = Icons.Default.AddCircle,
                    contentDescription ="Agregar",
                    tint = Color.White
                )
            }
        },
        floatingActionButtonPosition = FabPosition.End
    ){
        BodyContentFamilia(navController)
    }
}
@Composable
fun BodyContentFamilia(
    navController:NavController
){
    var familiaNombre by remember { mutableStateOf("") }
    var familiaFecha by remember { mutableStateOf("") }
    var familiaReseña by remember { mutableStateOf("") }
    Box(modifier = Modifier.fillMaxWidth()){
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(all = 16.dp)
        ) {
            TextField(
                modifier = Modifier.fillMaxWidth(),
                value=familiaNombre,
                onValueChange={familiaNombre= it},
                label ={ Text("Puntuacion: ") }
            )
            Spacer(modifier = Modifier.height(20.dp))
            TextField(
                modifier = Modifier.fillMaxWidth(),
                value=familiaFecha,
                onValueChange={familiaFecha= it},
                label ={ Text("Critica: ") }
            )
            Spacer(modifier = Modifier.height(20.dp))
            TextField(
                modifier = Modifier.fillMaxWidth(),
                value=familiaReseña,
                onValueChange={familiaReseña= it},
                label ={ Text("Critica: ") }
            )
            Spacer(modifier = Modifier.height(20.dp))
            Button(
                onClick = {
                    val familis = Familia(familiaNombre,familiaFecha.toInt(),familiaReseña)
                    Firebase.firestore.collection("familis").add(familis)
                    navController.navigate(route =Nave.AppFamilia.route)
                },
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .padding(vertical = 8.dp)
                    .fillMaxWidth()
            ) {
                Text(text = "Crear comentario")
            }
        }
    }
}