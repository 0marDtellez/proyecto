package com.example.prollectofinal.scrins

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import androidx.navigation.NavController
import com.example.prollectofinal.R
import com.example.prollectofinal.navegar.Nave

@Composable
fun Categorias(
    navController: NavController
) {
    val Accion = painterResource(R.drawable.shanks)
    val Terror = painterResource(R.drawable.orochi)
    val Familiar = painterResource(R.drawable.otohime)
    val Comedia = painterResource(R.drawable.enel)
    val logo = painterResource(R.drawable.raikuasa)
Box(){
    Image(
        modifier= Modifier
            .fillMaxSize()
            .padding(1.dp),
        painter =logo,
        contentDescription ="mika"
    )
    Column(
    ) {
        Row(
            modifier = Modifier.clickable { navController.navigate(route = Nave.AppAccio.route) }
        ) {
            Image(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(10.dp)
                    .clip(CircleShape),
                painter = Accion,
                contentDescription = "yamato"
            )
            Text(
                text = "Accion",
                fontFamily = FontFamily.Serif,
                textAlign = TextAlign.Center
            )

        }
        Spacer(modifier = Modifier.padding(10.dp))
        Row(
            modifier = Modifier.clickable { navController.navigate(route = Nave.AppTerror.route) }
        ) {
            Image(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp)
                    .clip(CircleShape),
                painter = Terror,
                contentDescription = "yamato"
            )
            Text(
                text = "Terror",
                fontFamily = FontFamily.Serif,
                textAlign = TextAlign.Center
            )
        }
        Spacer(modifier = Modifier.padding(10.dp))
        Row(
            modifier = Modifier.clickable { navController.navigate(route = Nave.AppFamilia.route) }
        ) {
            Image(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp)
                    .clip(CircleShape),
                painter = Familiar,
                contentDescription = "yamato"
            )
            Text(
                text = "Familiar",
                fontFamily = FontFamily.Serif,
                textAlign = TextAlign.Center
            )
        }
        Spacer(modifier = Modifier.padding(10.dp))
        Row(
            modifier = Modifier.clickable { navController.navigate(route = Nave.AppComedia.route) }
        ) {
            Image(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp)
                    .clip(CircleShape),
                painter = Comedia,
                contentDescription = "yamato"
            )
            Text(
                text = "Comedia",
                fontFamily = FontFamily.Serif,
                textAlign = TextAlign.Center
            )
        }
    }
}
}