package com.example.prollectofinal.models

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.firestore.ktx.toObjects
import com.google.firebase.ktx.Firebase

class FamiliaViewModel: ViewModel()  {
    private  val _familia = mutableStateOf<List<Familia>>(emptyList())
    val famili: State<List<Familia>>
        get() = _familia
    private val query = Firebase.firestore.collection("accion")
    init {
        query.addSnapshotListener { value, _ ->
            if (value !=null){
                _familia.value = value.toObjects()
            }
        }
    }
}