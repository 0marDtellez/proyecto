package com.example.prollectofinal.navegar

import androidx.compose.runtime.*
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.prollectofinal.scrins.*
import com.example.prollectofinal.scrins.loguin.AddScreenFamilia
import com.example.prollectofinal.scrins.loguin.Login
import com.example.prollectofinal.scrins.loguin.models.MainViewModel


@Composable
fun AppNav(
    isLoading:Boolean,
    siono: Boolean,
    onLoginClick: () -> Unit,
    MainviewModel: MainViewModel
){
    val navController= rememberNavController()
    NavHost(
        navController =navController,
        startDestination =Nave.Vistas.route,
        ){
        composable(route=Nave.Vistas.route){ Vistas(navController)}
        //composable(route=Nave.Login.route){ Login(navController) }
        composable(route=Nave.Login.route){
            if (siono){
                LaunchedEffect(key1 =Unit){
                    navController.navigate(
                        Nave.Categorias.route
                    ){
                        popUpTo(Nave.Login.route){
                            inclusive=true
                        }
                    }
                }
            }else{
                Login(
                    isLoading,
                    siono,
                    onLoginClick,
                    MainviewModel,
                    navController
                )
            }
        }
        composable(route=Nave.Categorias.route){Categorias(navController)}
        composable(route=Nave.AppAccio.route){ AppAccio(navController, viewModel())}
        composable(route=Nave.AppTerror.route){AppTerror(navController, viewModel())}
        composable(route=Nave.AppFamilia.route){AppFamilia(navController, viewModel())}
        composable(route=Nave.AppComedia.route){AppComedia(navController, viewModel())}
        composable(route=Nave.AddScreenAccion.route){ AddScreenAccion(navController)}
        composable(route = Nave.AddScreenTerror.route){AddScreenTerror(navController)}
        composable(route = Nave.AddScreenFamilia.route){AddScreenFamilia(navController)}
        composable(route = Nave.AddScreenComedia.route){AddScreenComedia(navController)}
    }
}
