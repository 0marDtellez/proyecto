package com.example.prollectofinal.scrins

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.prollectofinal.R
import com.example.prollectofinal.navegar.Nave

@Composable
fun Vistas(
    navController: NavController,
){
    val logo= painterResource(R.drawable.raikuasa)
    Box(
        modifier = Modifier
            .clickable { navController.navigate(route = Nave.Login.route) }
            .background(MaterialTheme.colors.background),

    ){
        Image(
            modifier=Modifier
                .fillMaxSize()
                .padding(1.dp),
            painter =logo,
            contentDescription ="mika"
        )
        Column(
            verticalArrangement = Arrangement.SpaceAround,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.padding(50.dp))
            Text(
                text = "Califica tu pelicula faborita",
                fontSize =36.sp,
                textAlign = TextAlign.Center,
                fontFamily = FontFamily.Serif
            )
            Spacer(modifier = Modifier.padding(200.dp))
            Column(
                modifier = Modifier
                    .fillMaxSize()

            ) {
                Text(
                    modifier=Modifier.padding(5.dp,5.dp,5.dp,5.dp),
                    textAlign = TextAlign.Center,
                    fontSize =25.sp,
                    text = "App para poder calificar y dar una critica a tu pelicula faborita",
                    fontFamily = FontFamily.Serif
                )
            }
        }
    }
}