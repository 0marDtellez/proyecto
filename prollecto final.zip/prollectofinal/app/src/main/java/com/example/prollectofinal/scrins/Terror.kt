package com.example.prollectofinal.scrins

import android.annotation.SuppressLint
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.prollectofinal.R
import com.example.prollectofinal.models.Terro
import com.example.prollectofinal.models.TerrorViewModel
import com.example.prollectofinal.navegar.Nave

@Composable
fun TerrorCard(
    terro: Terro
){
    Card(
        modifier = Modifier
            .padding(all = 16.dp)
            .fillMaxWidth()
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Text(text = "Nombre: ${terro.nombre} ", color = Color.Gray, fontSize = 16.sp)
            Text(text = "Fecha:${terro.fecha}", color = Color.Gray)
            Text(text = "Reseña: ${terro.descripcion} ", color = Color.Gray, fontSize = 12.sp)
        }
    }
}
@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun AppTerror(
    navController: NavController,
    viewModel: TerrorViewModel
){
    val logo= painterResource(R.drawable.raikuasa)
    Scaffold(
        topBar = {
            TopAppBar(){
                Icon(
                    imageVector =Icons.Default.ArrowBack,
                    contentDescription ="Arrow Back",
                    modifier = Modifier
                        .clickable {
                            navController.popBackStack()
                        }
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "peliculas")
            }},
        floatingActionButton ={
            FloatingActionButton(
                modifier = Modifier.size(32.dp),
                onClick = {navController.navigate(route = Nave.AddScreenTerror.route)}
            ) {
                Icon(
                    imageVector = Icons.Default.AddCircle,
                    contentDescription ="Agregar",
                    tint = Color.White
                )
            }
        },
        floatingActionButtonPosition = FabPosition.End
    ){
        Box(modifier = Modifier.fillMaxSize()) {
            Image(
                painter =logo,
                contentDescription ="accion",
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(all = 4.dp)
            )
            Column() {
                LazyColumn(){
                    items(viewModel.terro.value){accio ->
                        TerrorCard(accio)
                    }
                }
            }
        }
    }
}

