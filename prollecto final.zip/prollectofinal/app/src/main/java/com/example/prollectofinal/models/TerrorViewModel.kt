package com.example.prollectofinal.models

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.firestore.ktx.toObjects
import com.google.firebase.ktx.Firebase

class TerrorViewModel: ViewModel() {
    private  val _terro = mutableStateOf<List<Terro>>(emptyList())
    val terro: State<List<Terro>>
        get() = _terro
    private val query = Firebase.firestore.collection("terror")
    init {
        query.addSnapshotListener { value, _ ->
            if (value !=null){
                _terro.value = value.toObjects()
            }
        }
    }
}