package com.example.prollectofinal.models

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.firestore.ktx.toObjects
import com.google.firebase.ktx.Firebase

class ComediaViewModel: ViewModel() {
    private  val _comedi = mutableStateOf<List<Comedia>>(emptyList())
    val comedi: State<List<Comedia>>
        get() = _comedi
    private val query = Firebase.firestore.collection("comedia")
    init {
        query.addSnapshotListener { value, _ ->
            if (value !=null){
                _comedi.value = value.toObjects()
            }
        }
    }
}